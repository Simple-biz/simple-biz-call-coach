import dotenv from 'dotenv';

// Load environment variables FIRST (before any service imports)
dotenv.config();

import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import helmet from 'helmet';
import winston from 'winston';
import { db } from './services/database.service';
import { aiAnalysis } from './services/ai-analysis.service';

// Initialize logger
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    })
  ]
});

// Initialize Express app
const app = express();
const httpServer = createServer(app);

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || '*',
  credentials: true
}));
app.use(express.json());

// Health check endpoint
app.get('/health', (req, res) => {
  const dbStats = db.getPoolStats();
  const aiStatus = aiAnalysis.getStatus();
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    database: db.isConnected() ? 'connected' : 'disconnected',
    poolStats: dbStats,
    aiAnalysis: aiStatus
  });
});

// Initialize Socket.io
const io = new Server(httpServer, {
  cors: {
    origin: process.env.ALLOWED_ORIGINS?.split(',') || '*',
    credentials: true
  },
  transports: ['websocket', 'polling']
});

// Authentication middleware for Socket.io
io.use((socket, next) => {
  const apiKey = socket.handshake.auth.apiKey || socket.handshake.headers['x-api-key'];

  if (!apiKey) {
    logger.warn('Connection rejected: No API key provided');
    return next(new Error('Authentication required'));
  }

  if (apiKey !== process.env.API_KEY) {
    logger.warn('Connection rejected: Invalid API key');
    return next(new Error('Invalid API key'));
  }

  logger.info('Client authenticated successfully', {
    socketId: socket.id
  });
  next();
});

// Socket.io connection handler
io.on('connection', (socket) => {
  logger.info('Client connected', { socketId: socket.id });

  // Store conversation ID in socket data
  let conversationId: string | null = null;

  /**
   * START_CONVERSATION
   * Initiates a new coaching session
   */
  socket.on('START_CONVERSATION', async (payload) => {
    try {
      const { agentId, metadata } = payload;

      if (!agentId) {
        socket.emit('ERROR', {
          type: 'ERROR',
          payload: {
            message: 'agentId is required',
            code: 'MISSING_AGENT_ID'
          }
        });
        return;
      }

      // Create conversation in database
      const result = await db.query(
        `INSERT INTO conversations (agent_id, status, metadata)
         VALUES ($1, $2, $3)
         RETURNING id, agent_id, start_time, status, metadata`,
        [agentId, 'active', metadata ? JSON.stringify(metadata) : null]
      );

      conversationId = result.rows[0].id;

      logger.info('Conversation started', {
        conversationId,
        agentId,
        socketId: socket.id
      });

      // Start AI analysis monitoring
      if (conversationId) {
        aiAnalysis.startMonitoring(conversationId, (data) => {
          socket.emit(data.type, data);
        });
      }

      // Send confirmation
      socket.emit('CONVERSATION_STARTED', {
        type: 'CONVERSATION_STARTED',
        payload: {
          conversationId,
          agentId,
          startTime: result.rows[0].start_time,
          timestamp: Date.now()
        }
      });

    } catch (error) {
      logger.error('Error starting conversation:', error);
      socket.emit('ERROR', {
        type: 'ERROR',
        payload: {
          message: 'Failed to start conversation',
          code: 'CONVERSATION_START_ERROR'
        }
      });
    }
  });

  /**
   * TRANSCRIPT
   * Receives streaming transcription data
   */
  socket.on('TRANSCRIPT', async (payload) => {
    try {
      const { conversationId: msgConvId, speaker, text, isFinal, timestamp } = payload;

      if (!msgConvId) {
        socket.emit('ERROR', {
          type: 'ERROR',
          payload: {
            message: 'conversationId is required',
            code: 'MISSING_CONVERSATION_ID'
          }
        });
        return;
      }

      if (!speaker || !text) {
        socket.emit('ERROR', {
          type: 'ERROR',
          payload: {
            message: 'speaker and text are required',
            code: 'INVALID_TRANSCRIPT'
          }
        });
        return;
      }

      // Store transcript in database
      await db.query(
        `INSERT INTO transcripts (conversation_id, speaker, text, is_final, timestamp)
         VALUES ($1, $2, $3, $4, $5)`,
        [
          msgConvId,
          speaker,
          text,
          isFinal ?? false,
          timestamp ? new Date(timestamp) : new Date()
        ]
      );

      logger.debug('Transcript stored', {
        conversationId: msgConvId,
        speaker,
        isFinal,
        textLength: text.length
      });

      // Acknowledge receipt
      socket.emit('TRANSCRIPT_RECEIVED', {
        type: 'TRANSCRIPT_RECEIVED',
        payload: {
          conversationId: msgConvId,
          timestamp: Date.now()
        }
      });

    } catch (error) {
      logger.error('Error storing transcript:', error);
      socket.emit('ERROR', {
        type: 'ERROR',
        payload: {
          message: 'Failed to store transcript',
          code: 'TRANSCRIPT_STORE_ERROR'
        }
      });
    }
  });

  /**
   * OPTION_SELECTED
   * Tracks which dialogue option the agent selected
   */
  socket.on('OPTION_SELECTED', async (payload) => {
    try {
      const { recommendationId, selectedOption } = payload;

      if (!recommendationId) {
        socket.emit('ERROR', {
          type: 'ERROR',
          payload: {
            message: 'recommendationId is required',
            code: 'MISSING_RECOMMENDATION_ID'
          }
        });
        return;
      }

      if (![1, 2, 3].includes(selectedOption)) {
        socket.emit('ERROR', {
          type: 'ERROR',
          payload: {
            message: 'selectedOption must be 1, 2, or 3',
            code: 'INVALID_OPTION'
          }
        });
        return;
      }

      // Update recommendation with selected option
      await db.query(
        `UPDATE ai_recommendations
         SET selected_option = $1, selected_at = $2
         WHERE id = $3`,
        [selectedOption, new Date(), recommendationId]
      );

      logger.info('Option selected', {
        recommendationId,
        selectedOption,
        socketId: socket.id
      });

      // Acknowledge selection
      socket.emit('OPTION_SELECTED_ACK', {
        type: 'OPTION_SELECTED_ACK',
        payload: {
          recommendationId,
          selectedOption,
          timestamp: Date.now()
        }
      });

    } catch (error) {
      logger.error('Error recording option selection:', error);
      socket.emit('ERROR', {
        type: 'ERROR',
        payload: {
          message: 'Failed to record option selection',
          code: 'OPTION_SELECTION_ERROR'
        }
      });
    }
  });

  /**
   * END_CONVERSATION
   * Marks conversation as ended
   */
  socket.on('END_CONVERSATION', async (payload) => {
    try {
      const { conversationId: msgConvId } = payload;

      if (!msgConvId) {
        socket.emit('ERROR', {
          type: 'ERROR',
          payload: {
            message: 'conversationId is required',
            code: 'MISSING_CONVERSATION_ID'
          }
        });
        return;
      }

      // Update conversation status
      await db.query(
        `UPDATE conversations
         SET status = $1, end_time = $2
         WHERE id = $3`,
        ['ended', new Date(), msgConvId]
      );

      // Stop AI analysis monitoring
      aiAnalysis.stopMonitoring(msgConvId);

      logger.info('Conversation ended', {
        conversationId: msgConvId,
        socketId: socket.id
      });

      socket.emit('CONVERSATION_ENDED', {
        type: 'CONVERSATION_ENDED',
        payload: {
          conversationId: msgConvId,
          endTime: Date.now(),
          timestamp: Date.now()
        }
      });

      conversationId = null;

    } catch (error) {
      logger.error('Error ending conversation:', error);
      socket.emit('ERROR', {
        type: 'ERROR',
        payload: {
          message: 'Failed to end conversation',
          code: 'CONVERSATION_END_ERROR'
        }
      });
    }
  });

  /**
   * PING (for connection testing)
   */
  socket.on('PING', () => {
    socket.emit('PONG', {
      type: 'PONG',
      payload: {
        timestamp: Date.now()
      }
    });
  });

  /**
   * Disconnect handler
   */
  socket.on('disconnect', (reason) => {
    logger.info('Client disconnected', {
      socketId: socket.id,
      reason,
      conversationId
    });
  });

  /**
   * Error handler
   */
  socket.on('error', (error) => {
    logger.error('Socket error:', {
      socketId: socket.id,
      error
    });
  });
});

// Start server
const PORT = process.env.PORT || 3000;

async function startServer() {
  try {
    // Connect to database
    await db.connect();

    // Start HTTP server
    httpServer.listen(PORT, () => {
      logger.info(`🚀 Server running on port ${PORT}`);
      logger.info(`📊 Health check: http://localhost:${PORT}/health`);
      logger.info(`🔌 WebSocket: ws://localhost:${PORT}`);
    });

  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down gracefully');
  httpServer.close(async () => {
    await db.disconnect();
    process.exit(0);
  });
});

process.on('SIGINT', async () => {
  logger.info('SIGINT received, shutting down gracefully');
  httpServer.close(async () => {
    await db.disconnect();
    process.exit(0);
  });
});

// Start the server
startServer();
