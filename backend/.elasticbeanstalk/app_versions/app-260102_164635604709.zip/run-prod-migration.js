/**
 * Run migration directly on production database
 * This script connects to production RDS and runs the email_reports migration
 */

const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');

// Production database connection
const DATABASE_URL = 'postgresql://dbadmin:cv8A0qYmuuW30JjZgkoOod8f6kbMooME@devassist-call-coach-db.cy5ki6sce1l1.us-east-1.rds.amazonaws.com:5432/devassist_call_coach';

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: {
    rejectUnauthorized: false // Required for RDS
  }
});

async function runMigration() {
  const client = await pool.connect();

  try {
    console.log('🔌 Connected to production database');

    // Check if migration already ran
    const checkResult = await client.query(
      "SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'email_reports')"
    );

    if (checkResult.rows[0].exists) {
      console.log('✅ Migration already applied - email_reports table exists');
      console.log('   Skipping migration to avoid duplicate execution');
      return;
    }

    console.log('📝 Reading migration SQL file...');
    const migrationSQL = fs.readFileSync(
      path.join(__dirname, 'migrations', '003_add_email_reports.sql'),
      'utf8'
    );

    console.log('🚀 Running migration 003_add_email_reports...');

    // Execute migration SQL
    await client.query(migrationSQL);

    console.log('✅ Migration completed successfully!');
    console.log('');
    console.log('Created:');
    console.log('  - email_reports table');
    console.log('  - 4 indexes (conversation_id, recipient_email, sent_at, status)');
    console.log('  - Comments and constraints');

  } catch (error) {
    console.error('❌ Migration failed:', error.message);
    console.error('');
    console.error('Error details:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

// Run the migration
runMigration()
  .then(() => {
    console.log('');
    console.log('🎉 Production database is ready for email feature!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('');
    console.error('💥 Migration failed - please check the error above');
    process.exit(1);
  });
