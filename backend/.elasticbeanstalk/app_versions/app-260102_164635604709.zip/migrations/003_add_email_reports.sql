-- Migration 003: Add Email Reports Tracking
-- Created: 2026-01-02
-- Purpose: Track email report deliveries for debugging and analytics

-- Email Reports table
CREATE TABLE email_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,

  -- Recipients
  recipient_email VARCHAR(255) NOT NULL,
  cc_emails JSONB, -- Array of CC email addresses

  -- Delivery tracking
  sent_at TIMESTAMP NOT NULL DEFAULT NOW(),
  status VARCHAR(20) NOT NULL CHECK (status IN ('sent', 'failed')),
  error_message TEXT,

  -- Email provider metadata
  email_provider VARCHAR(50) NOT NULL, -- 'ses', 'sendgrid', etc.
  message_id VARCHAR(255), -- Provider's message ID for tracking

  -- Metadata
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_email_reports_conversation_id ON email_reports(conversation_id);
CREATE INDEX idx_email_reports_recipient_email ON email_reports(recipient_email);
CREATE INDEX idx_email_reports_sent_at ON email_reports(sent_at);
CREATE INDEX idx_email_reports_status ON email_reports(status);

-- Comments
COMMENT ON TABLE email_reports IS 'Tracks email report deliveries for call diagnostics';
COMMENT ON COLUMN email_reports.status IS 'Values: sent, failed';
COMMENT ON COLUMN email_reports.email_provider IS 'Email service used: ses, sendgrid, mailgun, etc.';
COMMENT ON COLUMN email_reports.message_id IS 'Provider-specific message ID for delivery tracking';
