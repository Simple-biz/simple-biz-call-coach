const { Pool } = require('pg');

const migrationSQL = `
-- Migration 003: Add Email Reports Tracking
CREATE TABLE IF NOT EXISTS email_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  recipient_email VARCHAR(255) NOT NULL,
  cc_emails JSONB,
  sent_at TIMESTAMP NOT NULL DEFAULT NOW(),
  status VARCHAR(20) NOT NULL CHECK (status IN ('sent', 'failed')),
  error_message TEXT,
  email_provider VARCHAR(50) NOT NULL,
  message_id VARCHAR(255),
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_email_reports_conversation_id ON email_reports(conversation_id);
CREATE INDEX IF NOT EXISTS idx_email_reports_recipient_email ON email_reports(recipient_email);
CREATE INDEX IF NOT EXISTS idx_email_reports_sent_at ON email_reports(sent_at);
CREATE INDEX IF NOT EXISTS idx_email_reports_status ON email_reports(status);
`;

const pool = new Pool({
  connectionString: 'postgresql://dbadmin:cv8A0qYmuuW30JjZgkoOod8f6kbMooME@devassist-call-coach-db.cy5ki6sce1l1.us-east-1.rds.amazonaws.com:5432/devassist_call_coach',
  ssl: { rejectUnauthorized: false }
});

pool.query(migrationSQL)
  .then(() => {
    console.log('✅ Migration successful!');
    return pool.end();
  })
  .then(() => process.exit(0))
  .catch(err => {
    console.error('❌ Error:', err.message);
    pool.end();
    process.exit(1);
  });
