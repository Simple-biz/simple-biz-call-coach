/**
 * Test script to send a sample email diagnostic report
 * Run with: node test-email.js
 */

const BACKEND_URL = 'http://localhost:3000';

// Sample call data
const testData = {
  callMetadata: {
    conversationId: 'test-' + Date.now(),
    agentId: 'test-agent-001',
    agentEmail: 'cobb@simple.biz', // Verified SES email
    ccEmails: [], // Add CC emails if needed
    customerPhone: '+1-555-0123',
    customerName: 'John Doe',
    startTime: new Date(Date.now() - 600000).toISOString(), // 10 minutes ago
    endTime: new Date().toISOString(),
    duration: 600, // 10 minutes
  },
  transcripts: [
    {
      speaker: 'agent',
      text: 'Hello, thank you for calling. How can I help you today?',
      timestamp: new Date(Date.now() - 580000).toISOString(),
      isFinal: true
    },
    {
      speaker: 'caller',
      text: 'Hi, I\'m having trouble with my recent order.',
      timestamp: new Date(Date.now() - 570000).toISOString(),
      isFinal: true
    },
    {
      speaker: 'agent',
      text: 'I\'d be happy to help you with that. Can you provide me with your order number?',
      timestamp: new Date(Date.now() - 560000).toISOString(),
      isFinal: true
    },
    {
      speaker: 'caller',
      text: 'Yes, it\'s order number 12345.',
      timestamp: new Date(Date.now() - 550000).toISOString(),
      isFinal: true
    },
    {
      speaker: 'agent',
      text: 'Thank you. Let me look that up for you.',
      timestamp: new Date(Date.now() - 540000).toISOString(),
      isFinal: true
    },
    {
      speaker: 'caller',
      text: 'The item I received doesn\'t match what I ordered.',
      timestamp: new Date(Date.now() - 530000).toISOString(),
      isFinal: true
    },
    {
      speaker: 'agent',
      text: 'I apologize for that inconvenience. I can help you process an exchange or refund.',
      timestamp: new Date(Date.now() - 520000).toISOString(),
      isFinal: true
    },
    {
      speaker: 'caller',
      text: 'I\'d prefer an exchange please.',
      timestamp: new Date(Date.now() - 510000).toISOString(),
      isFinal: true
    },
    {
      speaker: 'agent',
      text: 'Perfect. I\'ll process that exchange for you right away and send you a prepaid return label.',
      timestamp: new Date(Date.now() - 500000).toISOString(),
      isFinal: true
    },
    {
      speaker: 'caller',
      text: 'That sounds great, thank you!',
      timestamp: new Date(Date.now() - 490000).toISOString(),
      isFinal: true
    }
  ],
  aiTips: [
    {
      recommendationId: 'rec-001',
      timestamp: new Date(Date.now() - 550000).toISOString(),
      reason: 'Customer expressed frustration about order issue',
      options: [
        'I sincerely apologize for the inconvenience with your order. Let me make this right for you.',
        'I understand your frustration. I\'m here to help resolve this issue quickly.',
        'I\'m sorry to hear about the problem with your order. I\'ll take care of this right away.'
      ],
      selectedOption: 1
    },
    {
      recommendationId: 'rec-002',
      timestamp: new Date(Date.now() - 520000).toISOString(),
      reason: 'Opportunity to offer solution and show empathy',
      options: [
        'I can process an immediate exchange and expedite shipping at no extra cost.',
        'Would you prefer a full refund or an exchange for the correct item?',
        'Let me check our inventory and get the right item shipped to you today.'
      ],
      selectedOption: 2
    },
    {
      recommendationId: 'rec-003',
      timestamp: new Date(Date.now() - 500000).toISOString(),
      reason: 'Good time to confirm next steps and provide reassurance',
      options: [
        'I\'ll email you the return label within 5 minutes and your exchange will ship today.',
        'You should receive the return label shortly, and we\'ll expedite your replacement.',
        'I\'ve initiated the exchange and you\'ll receive tracking information via email.'
      ],
      selectedOption: 1
    }
  ]
};

async function testEmailReport() {
  console.log('🧪 Testing Email Diagnostic Report...\n');
  console.log('📧 Sending to:', testData.callMetadata.agentEmail);
  console.log('📊 Conversation ID:', testData.callMetadata.conversationId);
  console.log('📝 Transcripts:', testData.transcripts.length);
  console.log('💡 AI Tips:', testData.aiTips.length);
  console.log('');

  try {
    const response = await fetch(`${BACKEND_URL}/api/generate-report`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(testData)
    });

    const result = await response.json();

    if (response.ok && result.success) {
      console.log('✅ Email sent successfully!');
      console.log('📨 Message ID:', result.messageId);
      console.log('');
      console.log('📬 Check your inbox for the email diagnostic report.');
      console.log('   Look in spam folder if not in inbox.');
    } else {
      console.log('❌ Email failed to send');
      console.log('Error:', result.error);
      console.log('');
      console.log('Troubleshooting tips:');
      console.log('1. Check that EMAIL_FROM_ADDRESS is verified in AWS SES');
      console.log('2. If in SES sandbox, recipient email must also be verified');
      console.log('3. Check backend logs for detailed error messages');
    }

  } catch (error) {
    console.log('❌ Request failed:', error.message);
    console.log('');
    console.log('Troubleshooting tips:');
    console.log('1. Ensure backend server is running on port 3000');
    console.log('2. Check network connectivity');
    console.log('3. Verify backend URL is correct');
  }
}

// Run the test
testEmailReport();
