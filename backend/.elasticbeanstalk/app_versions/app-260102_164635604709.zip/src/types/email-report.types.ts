export interface CallMetadata {
  conversationId: string;
  agentEmail: string;
  ccEmails?: string[];
  startTime: number;
  endTime: number;
  duration: number;
  customerPhone?: string;
  customerName?: string;
}

export interface TranscriptEntry {
  timestamp: number;
  speaker: 'caller' | 'agent';
  text: string;
  confidence: number;
  isFinal: boolean;
}

export interface AITip {
  recommendationId: string;
  heading: string;
  stage: string;
  context: string;
  options: Array<{
    label: string;
    script: string;
  }>;
  selectedOption?: 1 | 2 | 3;
  timestamp: number;
}

export interface GenerateReportRequest {
  callMetadata: CallMetadata;
  transcripts: TranscriptEntry[];
  aiTips: AITip[];
}

export interface GenerateReportResponse {
  success: boolean;
  messageId?: string;
  error?: string;
}
