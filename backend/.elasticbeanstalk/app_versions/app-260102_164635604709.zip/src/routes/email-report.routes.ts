import { Router, Request, Response } from 'express';
import winston from 'winston';
import { emailService } from '../services/email.service';
import { emailTemplateService } from '../services/email-template.service';
import { validateEmailRequest } from '../middleware/validate-email-request.middleware';
import { emailRateLimiter } from '../middleware/rate-limit.middleware';
import { GenerateReportRequest, GenerateReportResponse } from '../types/email-report.types';

const router = Router();

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    })
  ]
});

/**
 * POST /api/generate-report
 * Generate and send call diagnostics email report
 */
router.post(
  '/generate-report',
  emailRateLimiter.middleware,
  validateEmailRequest,
  async (req: Request, res: Response) => {
    try {
      const body: GenerateReportRequest = req.body;
      const { callMetadata, transcripts, aiTips } = body;

      logger.info('Generating email report', {
        conversationId: callMetadata.conversationId,
        agentEmail: callMetadata.agentEmail,
        ccEmails: callMetadata.ccEmails,
        transcriptCount: transcripts.length,
        aiTipCount: aiTips.length,
      });

      // Generate email content
      const htmlBody = emailTemplateService.generateHTML(callMetadata, transcripts, aiTips);
      const textBody = emailTemplateService.generatePlainText(callMetadata, transcripts, aiTips);

      // Prepare recipient list
      const recipients = [callMetadata.agentEmail];
      if (callMetadata.ccEmails && callMetadata.ccEmails.length > 0) {
        recipients.push(...callMetadata.ccEmails);
      }

      // Generate subject line
      const callDate = new Date(callMetadata.startTime).toLocaleDateString();
      const subject = `Call Diagnostics Report - ${callDate}${callMetadata.customerName ? ` - ${callMetadata.customerName}` : ''}`;

      // Send email
      const result = await emailService.sendCallDiagnostics(
        recipients,
        subject,
        htmlBody,
        textBody,
        callMetadata.conversationId
      );

      if (result.success) {
        logger.info('Email report sent successfully', {
          conversationId: callMetadata.conversationId,
          messageId: result.messageId,
          recipients,
        });

        const response: GenerateReportResponse = {
          success: true,
          messageId: result.messageId,
        };
        return res.status(200).json(response);
      } else {
        logger.error('Email report failed', {
          conversationId: callMetadata.conversationId,
          error: result.error,
        });

        const response: GenerateReportResponse = {
          success: false,
          error: result.error || 'Failed to send email',
        };
        return res.status(500).json(response);
      }

    } catch (error: any) {
      logger.error('Error generating email report', {
        error: error.message,
        stack: error.stack,
      });

      const response: GenerateReportResponse = {
        success: false,
        error: 'Internal server error',
      };
      return res.status(500).json(response);
    }
  }
);

export default router;
