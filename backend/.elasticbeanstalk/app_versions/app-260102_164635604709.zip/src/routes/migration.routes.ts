import { Router, Request, Response } from 'express';
import { db } from '../services/database.service';

const router = Router();

/**
 * ONE-TIME MIGRATION ENDPOINT
 * Run the email_reports migration directly
 * Protected by API key
 */
router.post('/run-email-migration', async (req: Request, res: Response) => {
  const apiKey = req.headers['x-admin-key'];

  if (apiKey !== process.env.API_KEY) {
    return res.status(403).json({ error: 'Unauthorized' });
  }

  try {
    const migrationSQL = `
      -- Migration 003: Add Email Reports Tracking
      CREATE TABLE IF NOT EXISTS email_reports (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
        recipient_email VARCHAR(255) NOT NULL,
        cc_emails JSONB,
        sent_at TIMESTAMP NOT NULL DEFAULT NOW(),
        status VARCHAR(20) NOT NULL CHECK (status IN ('sent', 'failed')),
        error_message TEXT,
        email_provider VARCHAR(50) NOT NULL,
        message_id VARCHAR(255),
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_email_reports_conversation_id ON email_reports(conversation_id);
      CREATE INDEX IF NOT EXISTS idx_email_reports_recipient_email ON email_reports(recipient_email);
      CREATE INDEX IF NOT EXISTS idx_email_reports_sent_at ON email_reports(sent_at);
      CREATE INDEX IF NOT EXISTS idx_email_reports_status ON email_reports(status);
    `;

    await db.query(migrationSQL);

    res.json({
      status: 'success',
      message: 'Email reports migration completed successfully'
    });
  } catch (error: any) {
    res.status(500).json({
      status: 'error',
      message: error.message
    });
  }
});

export default router;
