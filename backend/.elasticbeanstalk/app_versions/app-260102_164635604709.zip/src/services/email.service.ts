import { SESClient, SendEmailCommand, SendEmailCommandInput } from '@aws-sdk/client-ses';
import winston from 'winston';
import { db } from './database.service';

class EmailService {
  private sesClient: SESClient | null = null;
  private logger: winston.Logger;
  private provider: string;
  private fromAddress: string;

  constructor() {
    this.logger = winston.createLogger({
      level: process.env.LOG_LEVEL || 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          )
        })
      ]
    });

    this.provider = process.env.EMAIL_SERVICE_PROVIDER || 'ses';
    this.fromAddress = process.env.EMAIL_FROM_ADDRESS || 'noreply@devassist.ai';

    // Validate configuration
    if (!this.fromAddress) {
      throw new Error('EMAIL_FROM_ADDRESS environment variable is required');
    }

    if (!this.validateEmail(this.fromAddress)) {
      throw new Error(`Invalid EMAIL_FROM_ADDRESS format: ${this.fromAddress}`);
    }

    // Initialize SES client if using AWS SES
    if (this.provider === 'ses') {
      const region = process.env.AWS_SES_REGION || 'us-east-1';

      if (!process.env.AWS_SES_REGION) {
        this.logger.warn('AWS_SES_REGION not set, using default: us-east-1');
      }

      this.sesClient = new SESClient({
        region,
        // Uses IAM role credentials from Elastic Beanstalk instance in production
        // Uses default credential chain in development (~/.aws/credentials)
      });

      this.logger.info('AWS SES email service initialized', {
        region,
        fromAddress: this.fromAddress
      });
    }
  }

  /**
   * Send call diagnostics email
   */
  async sendCallDiagnostics(
    to: string[],
    subject: string,
    htmlBody: string,
    textBody: string,
    conversationId: string
  ): Promise<{ success: boolean; messageId?: string; error?: string }> {
    try {
      let messageId: string | undefined;

      if (this.provider === 'ses') {
        if (!this.sesClient) {
          throw new Error('SES client not initialized');
        }

        const params: SendEmailCommandInput = {
          Source: this.fromAddress,
          Destination: {
            ToAddresses: to,
          },
          Message: {
            Subject: {
              Data: subject,
              Charset: 'UTF-8',
            },
            Body: {
              Html: {
                Data: htmlBody,
                Charset: 'UTF-8',
              },
              Text: {
                Data: textBody,
                Charset: 'UTF-8',
              },
            },
          },
        };

        const command = new SendEmailCommand(params);
        const response = await this.sesClient.send(command);
        messageId = response.MessageId;

        this.logger.info('Email sent successfully via SES', {
          messageId,
          recipients: to,
          conversationId
        });
      } else {
        throw new Error(`Email provider '${this.provider}' not supported`);
      }

      // Log to database
      await this.logEmailReport({
        conversationId,
        recipientEmail: to[0],
        ccEmails: to.length > 1 ? to.slice(1) : null,
        status: 'sent',
        emailProvider: this.provider,
        messageId: messageId || null,
        errorMessage: null,
      });

      return { success: true, messageId };

    } catch (error: any) {
      this.logger.error('Failed to send email', {
        error: error.message,
        conversationId,
        recipients: to
      });

      // Log failure to database
      await this.logEmailReport({
        conversationId,
        recipientEmail: to[0],
        ccEmails: to.length > 1 ? to.slice(1) : null,
        status: 'failed',
        emailProvider: this.provider,
        messageId: null,
        errorMessage: error.message,
      });

      return { success: false, error: error.message };
    }
  }

  /**
   * Log email report to database
   */
  private async logEmailReport(data: {
    conversationId: string;
    recipientEmail: string;
    ccEmails: string[] | null;
    status: 'sent' | 'failed';
    emailProvider: string;
    messageId: string | null;
    errorMessage: string | null;
  }): Promise<void> {
    try {
      await db.query(
        `INSERT INTO email_reports (conversation_id, recipient_email, cc_emails, status, email_provider, message_id, error_message)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [
          data.conversationId,
          data.recipientEmail,
          data.ccEmails ? JSON.stringify(data.ccEmails) : null,
          data.status,
          data.emailProvider,
          data.messageId,
          data.errorMessage,
        ]
      );
    } catch (error) {
      this.logger.error('Failed to log email report to database', { error });
      // Don't throw - logging failure shouldn't block email sending
    }
  }

  /**
   * Validate email address format
   * Follows RFC 5321 standards
   */
  validateEmail(email: string): boolean {
    // Check if email exists and is within length limits (RFC 5321)
    if (!email || email.length > 254) {
      return false;
    }

    // More robust email regex
    const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

    if (!emailRegex.test(email)) {
      return false;
    }

    // Validate local part and domain part lengths
    const parts = email.split('@');
    if (parts.length !== 2) {
      return false;
    }

    const [localPart, domainPart] = parts;

    // Local part (before @) max 64 chars, domain part max 253 chars
    if (localPart.length > 64 || domainPart.length > 253) {
      return false;
    }

    // Domain must have at least one dot and valid TLD
    if (!domainPart.includes('.') || domainPart.endsWith('.')) {
      return false;
    }

    return true;
  }

  /**
   * Get service status
   */
  getStatus() {
    return {
      provider: this.provider,
      fromAddress: this.fromAddress,
      initialized: this.sesClient !== null,
    };
  }
}

export const emailService = new EmailService();
