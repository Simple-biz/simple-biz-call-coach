import { CallMetadata, TranscriptEntry, AITip } from '../types/email-report.types';

class EmailTemplateService {
  /**
   * Generate HTML email template
   */
  generateHTML(
    metadata: CallMetadata,
    transcripts: TranscriptEntry[],
    aiTips: AITip[]
  ): string {
    const duration = this.formatDuration(metadata.duration);
    const callDate = new Date(metadata.startTime).toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    const transcriptHTML = this.generateTranscriptHTML(transcripts);
    const aiTipsHTML = this.generateAITipsHTML(aiTips);
    const statsHTML = this.generateStatsHTML(transcripts, aiTips, metadata.duration);

    return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Call Diagnostics Report</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
      background-color: #f5f5f5;
    }
    .container {
      background-color: #ffffff;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      overflow: hidden;
    }
    .header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 30px;
      text-align: center;
    }
    .header h1 {
      margin: 0;
      font-size: 24px;
      font-weight: 600;
    }
    .section {
      padding: 30px;
      border-bottom: 1px solid #e5e5e5;
    }
    .section:last-child {
      border-bottom: none;
    }
    .section h2 {
      margin-top: 0;
      margin-bottom: 20px;
      font-size: 20px;
      color: #667eea;
      border-bottom: 2px solid #667eea;
      padding-bottom: 10px;
    }
    .meta-info {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 15px;
      background-color: #f8f9fa;
      padding: 20px;
      border-radius: 6px;
    }
    .meta-item {
      display: flex;
      flex-direction: column;
    }
    .meta-label {
      font-size: 12px;
      text-transform: uppercase;
      color: #666;
      margin-bottom: 5px;
    }
    .meta-value {
      font-size: 16px;
      font-weight: 600;
      color: #333;
    }
    .transcript-entry {
      margin-bottom: 20px;
      padding: 15px;
      background-color: #f8f9fa;
      border-left: 4px solid #667eea;
      border-radius: 4px;
    }
    .transcript-entry.agent {
      border-left-color: #48bb78;
    }
    .transcript-entry.caller {
      border-left-color: #4299e1;
    }
    .transcript-header {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;
      font-size: 13px;
    }
    .speaker {
      font-weight: 600;
      text-transform: capitalize;
    }
    .speaker.agent {
      color: #48bb78;
    }
    .speaker.caller {
      color: #4299e1;
    }
    .timestamp {
      color: #666;
      font-size: 12px;
    }
    .transcript-text {
      color: #333;
      line-height: 1.5;
    }
    .ai-tip {
      margin-bottom: 25px;
      padding: 20px;
      background-color: #fff5f5;
      border: 1px solid #feb2b2;
      border-radius: 6px;
    }
    .tip-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
    }
    .tip-heading {
      font-size: 16px;
      font-weight: 600;
      color: #c53030;
    }
    .tip-stage {
      font-size: 12px;
      padding: 4px 12px;
      background-color: #667eea;
      color: white;
      border-radius: 12px;
    }
    .tip-context {
      color: #555;
      margin-bottom: 15px;
      font-style: italic;
    }
    .tip-options {
      margin-top: 15px;
    }
    .tip-option {
      margin-bottom: 12px;
      padding: 12px;
      background-color: white;
      border: 1px solid #e2e8f0;
      border-radius: 4px;
    }
    .tip-option.selected {
      background-color: #c6f6d5;
      border-color: #48bb78;
    }
    .option-label {
      font-weight: 600;
      color: #667eea;
      margin-bottom: 5px;
    }
    .option-script {
      color: #333;
    }
    .stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 20px;
    }
    .stat-card {
      text-align: center;
      padding: 20px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border-radius: 6px;
    }
    .stat-value {
      font-size: 32px;
      font-weight: 700;
      margin-bottom: 5px;
    }
    .stat-label {
      font-size: 14px;
      opacity: 0.9;
    }
    .footer {
      padding: 30px;
      text-align: center;
      background-color: #f8f9fa;
      color: #666;
      font-size: 13px;
    }
    .disclaimer {
      margin-top: 15px;
      padding: 15px;
      background-color: #fff5f5;
      border-left: 4px solid #fc8181;
      border-radius: 4px;
      text-align: left;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>DevAssist Call Coach - Call Diagnostics Report</h1>
    </div>

    <div class="section">
      <h2>Call Summary</h2>
      <div class="meta-info">
        <div class="meta-item">
          <span class="meta-label">Date & Time</span>
          <span class="meta-value">${callDate}</span>
        </div>
        <div class="meta-item">
          <span class="meta-label">Duration</span>
          <span class="meta-value">${duration}</span>
        </div>
        ${metadata.customerName ? `
        <div class="meta-item">
          <span class="meta-label">Customer Name</span>
          <span class="meta-value">${this.escapeHtml(metadata.customerName)}</span>
        </div>
        ` : ''}
        ${metadata.customerPhone ? `
        <div class="meta-item">
          <span class="meta-label">Customer Phone</span>
          <span class="meta-value">${this.escapeHtml(metadata.customerPhone)}</span>
        </div>
        ` : ''}
        <div class="meta-item">
          <span class="meta-label">Conversation ID</span>
          <span class="meta-value" style="font-size: 12px;">${metadata.conversationId}</span>
        </div>
      </div>
    </div>

    <div class="section">
      <h2>Call Transcript</h2>
      ${transcriptHTML}
    </div>

    <div class="section">
      <h2>AI Coaching Tips</h2>
      ${aiTipsHTML}
    </div>

    <div class="section">
      <h2>Call Statistics</h2>
      ${statsHTML}
    </div>

    <div class="footer">
      <strong>DevAssist Call Coach</strong><br>
      Real-time AI-powered call coaching<br>
      <div class="disclaimer">
        <strong>Disclaimer:</strong> This report contains AI-generated content and coaching suggestions.
        All recommendations should be reviewed by a qualified sales manager before use in training or
        performance evaluation. Transcription accuracy may vary based on audio quality and background noise.
      </div>
    </div>
  </div>
</body>
</html>
    `;
  }

  /**
   * Generate plain text email
   */
  generatePlainText(
    metadata: CallMetadata,
    transcripts: TranscriptEntry[],
    aiTips: AITip[]
  ): string {
    const duration = this.formatDuration(metadata.duration);
    const callDate = new Date(metadata.startTime).toLocaleString();

    let text = `DEVASSIST CALL COACH - CALL DIAGNOSTICS REPORT\n`;
    text += `================================================\n\n`;

    text += `CALL SUMMARY\n`;
    text += `------------\n`;
    text += `Date: ${callDate}\n`;
    text += `Duration: ${duration}\n`;
    if (metadata.customerName) text += `Customer: ${metadata.customerName}\n`;
    if (metadata.customerPhone) text += `Phone: ${metadata.customerPhone}\n`;
    text += `Conversation ID: ${metadata.conversationId}\n\n`;

    text += `CALL TRANSCRIPT\n`;
    text += `---------------\n`;
    transcripts.forEach((entry) => {
      const time = new Date(entry.timestamp).toLocaleTimeString();
      const speaker = entry.speaker.toUpperCase();
      text += `[${time}] ${speaker}: ${entry.text}\n\n`;
    });

    text += `\nAI COACHING TIPS\n`;
    text += `----------------\n`;
    aiTips.forEach((tip, index) => {
      text += `\nTip ${index + 1}: ${tip.heading}\n`;
      text += `Stage: ${tip.stage}\n`;
      text += `Context: ${tip.context}\n`;
      text += `Options:\n`;
      tip.options.forEach((opt, i) => {
        const marker = tip.selectedOption === (i + 1) ? '[SELECTED]' : '';
        text += `  ${i + 1}. ${opt.label} ${marker}\n`;
        text += `     "${opt.script}"\n`;
      });
    });

    const wordCount = transcripts.reduce((sum, t) => sum + t.text.split(' ').length, 0);
    text += `\n\nCALL STATISTICS\n`;
    text += `---------------\n`;
    text += `Total AI Tips: ${aiTips.length}\n`;
    text += `Call Duration: ${duration}\n`;
    text += `Transcript Word Count: ${wordCount}\n\n`;

    text += `---\n`;
    text += `This report contains AI-generated content. Review with a qualified manager.\n`;

    return text;
  }

  /**
   * Generate transcript HTML
   */
  private generateTranscriptHTML(transcripts: TranscriptEntry[]): string {
    if (transcripts.length === 0) {
      return '<p style="color: #666;">No transcript data available.</p>';
    }

    return transcripts
      .filter(t => t.isFinal) // Only show final transcripts
      .map(entry => {
        const time = new Date(entry.timestamp).toLocaleTimeString();
        const speakerClass = entry.speaker.toLowerCase();
        return `
        <div class="transcript-entry ${speakerClass}">
          <div class="transcript-header">
            <span class="speaker ${speakerClass}">${entry.speaker}</span>
            <span class="timestamp">${time}</span>
          </div>
          <div class="transcript-text">${this.escapeHtml(entry.text)}</div>
        </div>
        `;
      })
      .join('');
  }

  /**
   * Generate AI tips HTML
   */
  private generateAITipsHTML(aiTips: AITip[]): string {
    if (aiTips.length === 0) {
      return '<p style="color: #666;">No AI coaching tips were generated during this call.</p>';
    }

    return aiTips.map(tip => {
      const optionsHTML = tip.options.map((opt, index) => {
        const optionNum = index + 1;
        const isSelected = tip.selectedOption === optionNum;
        return `
        <div class="tip-option ${isSelected ? 'selected' : ''}">
          <div class="option-label">${optionNum}. ${this.escapeHtml(opt.label)} ${isSelected ? '✓ SELECTED' : ''}</div>
          <div class="option-script">"${this.escapeHtml(opt.script)}"</div>
        </div>
        `;
      }).join('');

      return `
      <div class="ai-tip">
        <div class="tip-header">
          <span class="tip-heading">${this.escapeHtml(tip.heading)}</span>
          <span class="tip-stage">${this.escapeHtml(tip.stage)}</span>
        </div>
        <div class="tip-context">${this.escapeHtml(tip.context)}</div>
        <div class="tip-options">
          ${optionsHTML}
        </div>
      </div>
      `;
    }).join('');
  }

  /**
   * Generate statistics HTML
   */
  private generateStatsHTML(
    transcripts: TranscriptEntry[],
    aiTips: AITip[],
    duration: number
  ): string {
    const wordCount = transcripts.reduce((sum, t) => sum + t.text.split(' ').length, 0);
    const durationFormatted = this.formatDuration(duration);

    return `
    <div class="stats">
      <div class="stat-card">
        <div class="stat-value">${aiTips.length}</div>
        <div class="stat-label">AI Tips</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${durationFormatted}</div>
        <div class="stat-label">Duration</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${wordCount}</div>
        <div class="stat-label">Words Spoken</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${transcripts.filter(t => t.isFinal).length}</div>
        <div class="stat-label">Transcript Entries</div>
      </div>
    </div>
    `;
  }

  /**
   * Format duration from milliseconds to readable string
   */
  private formatDuration(ms: number): string {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (hours > 0) {
      return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`;
    } else {
      return `${seconds}s`;
    }
  }

  /**
   * Escape HTML to prevent injection
   * Safely handles null/undefined values
   */
  private escapeHtml(text: string | null | undefined): string {
    // Handle null/undefined
    if (text === null || text === undefined) {
      return '';
    }

    // Convert to string if not already
    const str = String(text);

    const map: { [key: string]: string } = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return str.replace(/[&<>"']/g, (m) => map[m]);
  }
}

export const emailTemplateService = new EmailTemplateService();
