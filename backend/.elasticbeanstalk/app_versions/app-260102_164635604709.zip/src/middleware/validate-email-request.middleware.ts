import { Request, Response, NextFunction } from 'express';
import { emailService } from '../services/email.service';
import { GenerateReportRequest } from '../types/email-report.types';

export function validateEmailRequest(req: Request, res: Response, next: NextFunction) {
  const body: GenerateReportRequest = req.body;

  // Validate required fields
  if (!body.callMetadata) {
    return res.status(400).json({
      success: false,
      error: 'Missing required field: callMetadata',
    });
  }

  if (!body.callMetadata.conversationId) {
    return res.status(400).json({
      success: false,
      error: 'Missing required field: callMetadata.conversationId',
    });
  }

  if (!body.callMetadata.agentEmail) {
    return res.status(400).json({
      success: false,
      error: 'Missing required field: callMetadata.agentEmail',
    });
  }

  // Validate email format
  if (!emailService.validateEmail(body.callMetadata.agentEmail)) {
    return res.status(400).json({
      success: false,
      error: 'Invalid email format: callMetadata.agentEmail',
    });
  }

  // Validate CC emails if provided
  if (body.callMetadata.ccEmails) {
    if (!Array.isArray(body.callMetadata.ccEmails)) {
      return res.status(400).json({
        success: false,
        error: 'callMetadata.ccEmails must be an array',
      });
    }

    for (const email of body.callMetadata.ccEmails) {
      if (!emailService.validateEmail(email)) {
        return res.status(400).json({
          success: false,
          error: `Invalid email format in ccEmails: ${email}`,
        });
      }
    }
  }

  // Validate transcripts array
  if (!Array.isArray(body.transcripts)) {
    return res.status(400).json({
      success: false,
      error: 'transcripts must be an array',
    });
  }

  // Validate aiTips array
  if (!Array.isArray(body.aiTips)) {
    return res.status(400).json({
      success: false,
      error: 'aiTips must be an array',
    });
  }

  // Validate required metadata fields
  const required = ['startTime', 'endTime', 'duration'];
  for (const field of required) {
    if (!(field in body.callMetadata)) {
      return res.status(400).json({
        success: false,
        error: `Missing required field: callMetadata.${field}`,
      });
    }
  }

  next();
}
