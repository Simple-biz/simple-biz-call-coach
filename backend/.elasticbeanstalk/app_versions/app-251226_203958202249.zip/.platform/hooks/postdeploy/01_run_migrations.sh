#!/bin/bash
#
# Post-deploy hook to run database migrations
# This script runs after each deployment to ensure migrations are up to date
#

set -e

echo "Running database migrations..."

# Navigate to application directory
cd /var/app/current

# Run migrations
npm run migrate:up

echo "Migrations completed successfully"
