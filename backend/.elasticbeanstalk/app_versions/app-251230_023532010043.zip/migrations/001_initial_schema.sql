-- DevAssist AI Coaching Backend - Initial Schema
-- Created: 2025-12-17

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Conversations table
CREATE TABLE conversations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  agent_id VARCHAR(255) NOT NULL,
  start_time TIMESTAMP NOT NULL DEFAULT NOW(),
  end_time TIMESTAMP,
  status VARCHAR(50) NOT NULL DEFAULT 'active',
  metadata JSONB,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Transcripts table
CREATE TABLE transcripts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  speaker VARCHAR(50) NOT NULL CHECK (speaker IN ('caller', 'agent')),
  text TEXT NOT NULL,
  timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
  is_final BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- AI Recommendations table
CREATE TABLE ai_recommendations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  heading VARCHAR(20) NOT NULL,
  suggestion TEXT NOT NULL,
  context TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Conversation Summaries table
CREATE TABLE conversation_summaries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  time_range VARCHAR(50) NOT NULL,
  summary TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Indexes for better query performance
CREATE INDEX idx_conversations_agent_id ON conversations(agent_id);
CREATE INDEX idx_conversations_start_time ON conversations(start_time);
CREATE INDEX idx_conversations_status ON conversations(status);

CREATE INDEX idx_transcripts_conversation_id ON transcripts(conversation_id);
CREATE INDEX idx_transcripts_timestamp ON transcripts(timestamp);
CREATE INDEX idx_transcripts_speaker ON transcripts(speaker);

CREATE INDEX idx_ai_recommendations_conversation_id ON ai_recommendations(conversation_id);
CREATE INDEX idx_ai_recommendations_created_at ON ai_recommendations(created_at);

CREATE INDEX idx_conversation_summaries_conversation_id ON conversation_summaries(conversation_id);

-- Function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger to update updated_at on conversations table
CREATE TRIGGER update_conversations_updated_at
BEFORE UPDATE ON conversations
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Function for data retention cleanup (30 days)
CREATE OR REPLACE FUNCTION cleanup_old_conversations()
RETURNS void AS $$
BEGIN
  DELETE FROM conversations
  WHERE created_at < NOW() - INTERVAL '30 days';
END;
$$ LANGUAGE plpgsql;

-- Comments for documentation
COMMENT ON TABLE conversations IS 'Stores active and historical call sessions';
COMMENT ON TABLE transcripts IS 'Real-time transcript data from Deepgram with speaker labels';
COMMENT ON TABLE ai_recommendations IS 'AI-generated coaching suggestions with 2-word headings';
COMMENT ON TABLE conversation_summaries IS 'Progressive summarization of conversations over time';

COMMENT ON COLUMN conversations.status IS 'Values: active, ended, error';
COMMENT ON COLUMN transcripts.speaker IS 'Values: caller, agent';
COMMENT ON COLUMN transcripts.is_final IS 'Indicates if this is a final or interim transcript';
COMMENT ON COLUMN ai_recommendations.heading IS 'Maximum 2 words for UI display';
COMMENT ON COLUMN conversation_summaries.time_range IS 'Format: 0-10min, 10-20min, etc.';
