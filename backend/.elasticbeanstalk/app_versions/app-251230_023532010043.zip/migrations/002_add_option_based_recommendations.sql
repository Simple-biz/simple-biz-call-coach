-- Migration 002: Add Option-Based Recommendations
-- Created: 2025-12-24
-- Purpose: Enable 3-option script generation for AI coaching

-- Drop the old ai_recommendations table structure
DROP TABLE IF EXISTS ai_recommendations CASCADE;

-- Recreate with new multi-option structure
CREATE TABLE ai_recommendations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,

  -- Coaching context
  heading VARCHAR(20) NOT NULL,
  stage VARCHAR(50) NOT NULL, -- GREETING, DISCOVERY, VALUE_PROP, OBJECTION_HANDLING, NEXT_STEPS
  context TEXT, -- Why this recommendation makes sense

  -- 3 dialogue options
  option1_label VARCHAR(50) NOT NULL, -- e.g., "Minimal", "Direct", "Friendly"
  option1_script TEXT NOT NULL, -- Actual words to say

  option2_label VARCHAR(50) NOT NULL,
  option2_script TEXT NOT NULL,

  option3_label VARCHAR(50) NOT NULL,
  option3_script TEXT NOT NULL,

  -- Metadata
  selected_option INT CHECK (selected_option IN (1, 2, 3)), -- Which option user clicked
  selected_at TIMESTAMP, -- When they selected it
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_ai_recommendations_conversation_id ON ai_recommendations(conversation_id);
CREATE INDEX idx_ai_recommendations_created_at ON ai_recommendations(created_at);
CREATE INDEX idx_ai_recommendations_stage ON ai_recommendations(stage);
CREATE INDEX idx_ai_recommendations_selected_option ON ai_recommendations(selected_option) WHERE selected_option IS NOT NULL;

-- Comments
COMMENT ON TABLE ai_recommendations IS 'AI-generated coaching tips with 3 selectable dialogue scripts';
COMMENT ON COLUMN ai_recommendations.stage IS 'Conversation stage: GREETING, DISCOVERY, VALUE_PROP, OBJECTION_HANDLING, NEXT_STEPS';
COMMENT ON COLUMN ai_recommendations.heading IS 'Maximum 2 words for UI display (e.g., Ask Discovery)';
COMMENT ON COLUMN ai_recommendations.option1_label IS 'Style label: Minimal, Explanative, or Contextual';
COMMENT ON COLUMN ai_recommendations.option1_script IS 'Exact words agent can say to customer';
COMMENT ON COLUMN ai_recommendations.selected_option IS '1, 2, or 3 - which option the agent clicked';
COMMENT ON COLUMN ai_recommendations.selected_at IS 'Timestamp when agent selected this option';
