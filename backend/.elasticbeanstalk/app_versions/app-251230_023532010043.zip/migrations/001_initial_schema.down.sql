-- Rollback migration for initial schema
-- This will drop all tables and functions in reverse order

-- Drop triggers
DROP TRIGGER IF EXISTS update_conversations_updated_at ON conversations;

-- Drop functions
DROP FUNCTION IF EXISTS cleanup_old_conversations();
DROP FUNCTION IF EXISTS update_updated_at_column();

-- Drop indexes (will be dropped automatically with tables, but explicit for clarity)
DROP INDEX IF EXISTS idx_conversation_summaries_conversation_id;
DROP INDEX IF EXISTS idx_ai_recommendations_created_at;
DROP INDEX IF EXISTS idx_ai_recommendations_conversation_id;
DROP INDEX IF EXISTS idx_transcripts_speaker;
DROP INDEX IF EXISTS idx_transcripts_timestamp;
DROP INDEX IF EXISTS idx_transcripts_conversation_id;
DROP INDEX IF EXISTS idx_conversations_status;
DROP INDEX IF EXISTS idx_conversations_start_time;
DROP INDEX IF EXISTS idx_conversations_agent_id;

-- Drop tables in reverse dependency order
DROP TABLE IF EXISTS conversation_summaries;
DROP TABLE IF EXISTS ai_recommendations;
DROP TABLE IF EXISTS transcripts;
DROP TABLE IF EXISTS conversations;

-- Drop extensions
DROP EXTENSION IF EXISTS "uuid-ossp";
