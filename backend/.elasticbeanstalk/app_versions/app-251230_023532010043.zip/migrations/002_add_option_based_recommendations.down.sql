-- Rollback Migration 002
-- Reverts to original single-suggestion structure

DROP TABLE IF EXISTS ai_recommendations CASCADE;

-- Recreate original structure
CREATE TABLE ai_recommendations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  heading VARCHAR(20) NOT NULL,
  suggestion TEXT NOT NULL,
  context TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_ai_recommendations_conversation_id ON ai_recommendations(conversation_id);
CREATE INDEX idx_ai_recommendations_created_at ON ai_recommendations(created_at);

COMMENT ON TABLE ai_recommendations IS 'AI-generated coaching suggestions with 2-word headings';
COMMENT ON COLUMN ai_recommendations.heading IS 'Maximum 2 words for UI display';
