#!/usr/bin/env node

/**
 * Standalone migration runner
 * Connects to RDS database and runs all pending migrations
 */

const { Client } = require('pg');
const fs = require('fs');
const path = require('path');

const DATABASE_URL = 'postgresql://dbadmin:cv8A0qYmuuW30JjZgkoOod8f6kbMooME@devassist-call-coach-db.cy5ki6sce1l1.us-east-1.rds.amazonaws.com:5432/devassist_call_coach';

async function runMigrations() {
  const client = new Client({
    connectionString: DATABASE_URL,
    ssl: { rejectUnauthorized: false }
  });

  try {
    console.log('Connecting to database...');
    await client.connect();
    console.log('✅ Connected to database');

    // Read migration files
    const migrationsDir = path.join(__dirname, 'backend/migrations');
    const migrationFiles = fs.readdirSync(migrationsDir)
      .filter(f => f.endsWith('.sql') && !f.endsWith('.down.sql'))
      .sort();

    console.log(`Found ${migrationFiles.length} migration files`);

    for (const file of migrationFiles) {
      console.log(`\nRunning migration: ${file}`);
      const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');

      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query('COMMIT');
        console.log(`✅ ${file} completed successfully`);
      } catch (error) {
        await client.query('ROLLBACK');
        if (error.message.includes('already exists')) {
          console.log(`⚠️  ${file} - tables already exist, skipping`);
        } else {
          throw error;
        }
      }
    }

    console.log('\n✅ All migrations completed successfully!');
  } catch (error) {
    console.error('❌ Migration failed:', error);
    process.exit(1);
  } finally {
    await client.end();
  }
}

runMigrations();
