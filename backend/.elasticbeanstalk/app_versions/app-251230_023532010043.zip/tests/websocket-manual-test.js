/**
 * Manual WebSocket Test Client
 * Tests the backend WebSocket server with Socket.io
 *
 * Run with: node tests/websocket-manual-test.js
 */

const io = require('socket.io-client');

const API_KEY = 'devassist-cce03814ca61352a852641fe9bb4542877975dd1d65d353ba0459add57c15efa';
const SERVER_URL = 'http://localhost:3000';

console.log('🔌 Connecting to WebSocket server...\n');

// Create Socket.io client
const socket = io(SERVER_URL, {
  auth: {
    apiKey: API_KEY
  },
  transports: ['websocket', 'polling']
});

let conversationId = null;

// Connection events
socket.on('connect', () => {
  console.log('✅ Connected to server');
  console.log(`   Socket ID: ${socket.id}\n`);

  // Test 1: Start a conversation
  console.log('📝 Test 1: Starting a new conversation...');
  socket.emit('START_CONVERSATION', {
    agentId: 'test-agent-001',
    metadata: {
      testRun: true,
      timestamp: new Date().toISOString()
    }
  });
});

socket.on('CONVERSATION_STARTED', (data) => {
  console.log('✅ Conversation started successfully');
  console.log(`   Conversation ID: ${data.payload.conversationId}`);
  console.log(`   Agent ID: ${data.payload.agentId}`);
  console.log(`   Start Time: ${data.payload.startTime}\n`);

  conversationId = data.payload.conversationId;

  // Test 2: Send transcript data
  console.log('📝 Test 2: Sending transcript data...');

  // Simulate a few transcript messages
  setTimeout(() => {
    socket.emit('TRANSCRIPT', {
      conversationId,
      speaker: 'caller',
      text: 'Hi, I\'m interested in learning more about your SEO services.',
      isFinal: true,
      timestamp: Date.now()
    });
  }, 1000);

  setTimeout(() => {
    socket.emit('TRANSCRIPT', {
      conversationId,
      speaker: 'agent',
      text: 'Great! I\'d be happy to help. What type of business are you running?',
      isFinal: true,
      timestamp: Date.now()
    });
  }, 2000);

  setTimeout(() => {
    socket.emit('TRANSCRIPT', {
      conversationId,
      speaker: 'caller',
      text: 'We run a small e-commerce store selling handmade crafts.',
      isFinal: true,
      timestamp: Date.now()
    });
  }, 3000);

  setTimeout(() => {
    socket.emit('TRANSCRIPT', {
      conversationId,
      speaker: 'agent',
      text: 'Perfect! SEO can really help boost visibility for e-commerce stores. Are you currently doing any SEO work?',
      isFinal: true,
      timestamp: Date.now()
    });
  }, 4000);

  // Test 3: End conversation after 8 seconds
  setTimeout(() => {
    console.log('\n📝 Test 3: Ending conversation...');
    socket.emit('END_CONVERSATION', { conversationId });
  }, 8000);

  // Disconnect after 10 seconds
  setTimeout(() => {
    console.log('\n🔌 Disconnecting from server...');
    socket.disconnect();
    process.exit(0);
  }, 10000);
});

socket.on('TRANSCRIPT_RECEIVED', (data) => {
  console.log('✅ Transcript acknowledged');
  console.log(`   Conversation ID: ${data.payload.conversationId}`);
});

socket.on('AI_TIP', (data) => {
  console.log('\n🤖 AI COACHING TIP RECEIVED:');
  console.log(`   Heading: "${data.payload.heading}"`);
  console.log(`   Suggestion: "${data.payload.suggestion}"`);
  console.log(`   Conversation ID: ${data.payload.conversationId}\n`);
});

socket.on('AI_ERROR', (data) => {
  console.log('\n⚠️  AI Error:');
  console.log(`   Message: ${data.payload.message}`);
  console.log(`   Code: ${data.payload.code}\n`);
});

socket.on('CONVERSATION_ENDED', (data) => {
  console.log('✅ Conversation ended successfully');
  console.log(`   Conversation ID: ${data.payload.conversationId}`);
  console.log(`   End Time: ${data.payload.endTime}\n`);
});

socket.on('ERROR', (data) => {
  console.error('❌ Server error:');
  console.error(`   Message: ${data.payload.message}`);
  console.error(`   Code: ${data.payload.code}\n`);
});

socket.on('connect_error', (error) => {
  console.error('❌ Connection error:', error.message);
  process.exit(1);
});

socket.on('disconnect', (reason) => {
  console.log(`\n🔌 Disconnected: ${reason}`);
});

// Handle process termination
process.on('SIGINT', () => {
  console.log('\n\n🛑 Test interrupted by user');
  socket.disconnect();
  process.exit(0);
});
