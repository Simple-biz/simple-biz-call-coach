import OpenAI from 'openai';
import winston from 'winston';
import { TranscriptContext } from '../models';
import { promptBuilder } from './prompt-builder.service';

/**
 * OpenAI Service
 * Handles AI-powered conversation analysis and coaching recommendations
 */
class OpenAIService {
  private client: OpenAI;
  private logger: winston.Logger;
  private model: string;

  constructor() {
    this.client = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    });

    this.model = process.env.OPENAI_MODEL || 'gpt-4o-mini';

    this.logger = winston.createLogger({
      level: process.env.LOG_LEVEL || 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          )
        })
      ]
    });
  }

  /**
   * Analyze conversation and generate 3-option coaching recommendation
   * Returns stage, heading, context, and 3 dialogue options
   */
  async analyzeConversation(
    transcripts: TranscriptContext[],
    previousSummary?: string,
    selectedOptionsHistory?: string
  ): Promise<{
    stage: string;
    heading: string;
    context: string;
    options: Array<{ label: string; script: string }>;
  }> {
    try {
      // Build prompts using PromptBuilder service
      const systemPrompt = promptBuilder.buildAnalysisSystemPrompt(
        previousSummary,
        selectedOptionsHistory
      );
      const userPrompt = promptBuilder.buildAnalysisUserPrompt(transcripts);

      // Validate token limits
      if (!promptBuilder.validateTokenLimit(systemPrompt, userPrompt)) {
        this.logger.warn('Prompt exceeds token limit, truncating context');
      }

      // Call OpenAI API with increased max_tokens for 3 options
      const response = await this.client.chat.completions.create({
        model: this.model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        temperature: 0.7,
        max_tokens: 500, // Increased for 3 options
        response_format: { type: 'json_object' }
      });

      const content = response.choices[0].message.content;
      if (!content) {
        throw new Error('No content returned from OpenAI');
      }

      const parsed = JSON.parse(content);

      // Validate heading length (max 20 chars for 2-word heading)
      if (parsed.heading && parsed.heading.length > 20) {
        parsed.heading = parsed.heading.substring(0, 20);
      }

      // Ensure all required fields exist
      if (!parsed.options || !Array.isArray(parsed.options) || parsed.options.length !== 3) {
        this.logger.warn('OpenAI did not return 3 options, using fallback', { parsed });
        parsed.options = this.getFallbackOptions();
      }

      // Ensure stage is valid
      const validStages = ['GREETING', 'DISCOVERY', 'VALUE_PROP', 'OBJECTION_HANDLING', 'NEXT_STEPS', 'CONVERSION'];
      if (!validStages.includes(parsed.stage)) {
        parsed.stage = 'DISCOVERY'; // Default fallback
      }

      this.logger.info('AI analysis completed', {
        stage: parsed.stage,
        heading: parsed.heading,
        optionCount: parsed.options.length,
        tokensUsed: response.usage?.total_tokens
      });

      return {
        stage: parsed.stage,
        heading: parsed.heading || 'Keep Engaging',
        context: parsed.context || '',
        options: parsed.options
      };

    } catch (error) {
      this.logger.error('Error analyzing conversation:', error);
      throw error;
    }
  }

  /**
   * Get fallback options if AI fails to generate proper response
   */
  private getFallbackOptions(): Array<{ label: string; script: string }> {
    return [
      {
        label: 'Minimal',
        script: 'Could you tell me more about what you need help with?'
      },
      {
        label: 'Explanative',
        script: 'I\'d like to better understand your situation so I can provide the most relevant recommendations. Could you share more about your current challenges?'
      },
      {
        label: 'Contextual',
        script: 'Based on what you\'ve mentioned, I think I can help. To make sure I recommend the right solution, could you walk me through what you\'re looking to achieve?'
      }
    ];
  }

  /**
   * Generate progressive summary of conversation
   * Used for context management (10-minute intervals)
   */
  async generateSummary(
    transcripts: TranscriptContext[],
    previousSummaries?: string[]
  ): Promise<string> {
    try {
      // Build prompts using PromptBuilder service
      const systemPrompt = promptBuilder.buildSummarySystemPrompt(previousSummaries);
      const userPrompt = promptBuilder.buildSummaryUserPrompt(transcripts);

      const response = await this.client.chat.completions.create({
        model: this.model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        temperature: 0.5,
        max_tokens: 400
      });

      const summary = response.choices[0].message.content || '';

      this.logger.info('Summary generated', {
        summaryLength: summary.length,
        tokensUsed: response.usage?.total_tokens
      });

      return summary;

    } catch (error) {
      this.logger.error('Error generating summary:', error);
      throw error;
    }
  }

  /**
   * Test OpenAI connection and API key validity
   */
  async testConnection(): Promise<boolean> {
    try {
      const response = await this.client.chat.completions.create({
        model: this.model,
        messages: [{ role: 'user', content: 'Test' }],
        max_tokens: 5
      });

      this.logger.info('OpenAI connection test successful', {
        model: this.model
      });

      return true;
    } catch (error) {
      this.logger.error('OpenAI connection test failed:', error);
      return false;
    }
  }
}

// Export singleton instance
export const openai = new OpenAIService();
