import winston from 'winston';
import { db } from './database.service';
import { openai } from './openai.service';
import { TranscriptContext } from '../models';

/**
 * AI Analysis Service
 * Manages progressive analysis with 3-min warmup and 30-second intervals
 */
class AIAnalysisService {
  private logger: winston.Logger;
  private analysisTimers: Map<string, NodeJS.Timeout> = new Map();
  private conversationStartTimes: Map<string, number> = new Map();
  private lastAnalysisTimes: Map<string, number> = new Map();
  private summaryTimers: Map<string, NodeJS.Timeout> = new Map();

  // Configuration constants
  private readonly WARMUP_DURATION_MS = parseInt(process.env.AI_WARMUP_DURATION_MS || '180000'); // 3 minutes
  private readonly ANALYSIS_INTERVAL_MS = parseInt(process.env.AI_ANALYSIS_INTERVAL_MS || '30000'); // 30 seconds
  private readonly SUMMARY_INTERVAL_MS = parseInt(process.env.SUMMARY_INTERVAL_MS || '600000'); // 10 minutes
  private readonly MAX_RETRY_ATTEMPTS = 3;

  constructor() {
    this.logger = winston.createLogger({
      level: process.env.LOG_LEVEL || 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          )
        })
      ]
    });
  }

  /**
   * Start monitoring a conversation for AI analysis
   */
  startMonitoring(conversationId: string, emitCallback: (data: any) => void): void {
    this.conversationStartTimes.set(conversationId, Date.now());

    this.logger.info('Started monitoring conversation', {
      conversationId,
      warmupDuration: this.WARMUP_DURATION_MS,
      analysisInterval: this.ANALYSIS_INTERVAL_MS
    });

    // Schedule first analysis after warmup period
    const warmupTimer = setTimeout(() => {
      this.performAnalysis(conversationId, emitCallback);

      // Then schedule recurring analysis every 30 seconds
      const intervalTimer = setInterval(() => {
        this.performAnalysis(conversationId, emitCallback);
      }, this.ANALYSIS_INTERVAL_MS);

      this.analysisTimers.set(conversationId, intervalTimer);
    }, this.WARMUP_DURATION_MS);

    // Schedule progressive summarization every 10 minutes
    const summaryTimer = setInterval(() => {
      this.generateProgressiveSummary(conversationId);
    }, this.SUMMARY_INTERVAL_MS);

    this.summaryTimers.set(conversationId, summaryTimer);
  }

  /**
   * Stop monitoring a conversation
   */
  stopMonitoring(conversationId: string): void {
    const analysisTimer = this.analysisTimers.get(conversationId);
    const summaryTimer = this.summaryTimers.get(conversationId);

    if (analysisTimer) {
      clearInterval(analysisTimer);
      this.analysisTimers.delete(conversationId);
    }

    if (summaryTimer) {
      clearInterval(summaryTimer);
      this.summaryTimers.delete(conversationId);
    }

    this.conversationStartTimes.delete(conversationId);
    this.lastAnalysisTimes.delete(conversationId);

    this.logger.info('Stopped monitoring conversation', { conversationId });
  }

  /**
   * Perform AI analysis on conversation with 3-option generation
   */
  private async performAnalysis(conversationId: string, emitCallback: (data: any) => void): Promise<void> {
    let attempt = 0;

    while (attempt < this.MAX_RETRY_ATTEMPTS) {
      try {
        // Get recent transcripts (last 5 minutes)
        const transcriptsResult = await db.query<TranscriptContext>(
          `SELECT speaker, text, timestamp
           FROM transcripts
           WHERE conversation_id = $1
           AND timestamp > NOW() - INTERVAL '5 minutes'
           AND is_final = true
           ORDER BY timestamp ASC`,
          [conversationId]
        );

        if (transcriptsResult.rows.length === 0) {
          this.logger.debug('No new transcripts for analysis', { conversationId });
          return;
        }

        // Get latest summary if exists
        const summaryResult = await db.query(
          `SELECT summary
           FROM conversation_summaries
           WHERE conversation_id = $1
           ORDER BY created_at DESC
           LIMIT 1`,
          [conversationId]
        );

        const previousSummary = summaryResult.rows[0]?.summary;

        // Get selected options history (last 5 selections)
        const selectedOptionsResult = await db.query(
          `SELECT heading, stage,
           CASE
             WHEN selected_option = 1 THEN option1_label || ': ' || option1_script
             WHEN selected_option = 2 THEN option2_label || ': ' || option2_script
             WHEN selected_option = 3 THEN option3_label || ': ' || option3_script
           END as selected_script
           FROM ai_recommendations
           WHERE conversation_id = $1
           AND selected_option IS NOT NULL
           ORDER BY selected_at DESC
           LIMIT 5`,
          [conversationId]
        );

        const selectedOptionsHistory = selectedOptionsResult.rows.length > 0
          ? selectedOptionsResult.rows
              .map(r => `[${r.stage}] ${r.heading}: ${r.selected_script}`)
              .reverse()
              .join('\n')
          : undefined;

        // Analyze with OpenAI (now returns 3 options)
        const analysis = await openai.analyzeConversation(
          transcriptsResult.rows,
          previousSummary,
          selectedOptionsHistory
        );

        // Store recommendation with 3 options in database
        const result = await db.query(
          `INSERT INTO ai_recommendations (
            conversation_id, heading, stage, context,
            option1_label, option1_script,
            option2_label, option2_script,
            option3_label, option3_script
          )
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
          RETURNING id`,
          [
            conversationId,
            analysis.heading,
            analysis.stage,
            analysis.context,
            analysis.options[0].label,
            analysis.options[0].script,
            analysis.options[1].label,
            analysis.options[1].script,
            analysis.options[2].label,
            analysis.options[2].script
          ]
        );

        const recommendationId = result.rows[0].id;

        this.lastAnalysisTimes.set(conversationId, Date.now());

        // Emit AI tip with 3 options to client
        emitCallback({
          type: 'AI_TIP',
          payload: {
            recommendationId,
            conversationId,
            stage: analysis.stage,
            heading: analysis.heading,
            context: analysis.context,
            options: analysis.options,
            timestamp: Date.now()
          }
        });

        this.logger.info('AI analysis completed', {
          conversationId,
          stage: analysis.stage,
          heading: analysis.heading,
          optionCount: analysis.options.length
        });

        return; // Success, exit retry loop

      } catch (error) {
        attempt++;
        this.logger.error(`AI analysis attempt ${attempt} failed:`, {
          conversationId,
          error
        });

        if (attempt >= this.MAX_RETRY_ATTEMPTS) {
          // Emit error to client
          emitCallback({
            type: 'AI_ERROR',
            payload: {
              conversationId,
              message: 'AI analysis failed after retries',
              code: 'AI_ANALYSIS_ERROR',
              timestamp: Date.now()
            }
          });

          return;
        }

        // Wait before retry (exponential backoff)
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
      }
    }
  }

  /**
   * Generate progressive summary
   */
  private async generateProgressiveSummary(conversationId: string): Promise<void> {
    try {
      const startTime = this.conversationStartTimes.get(conversationId);
      if (!startTime) return;

      const elapsedMinutes = Math.floor((Date.now() - startTime) / 60000);
      const timeRange = `${elapsedMinutes - 10}-${elapsedMinutes}min`;

      // Get transcripts from last 10 minutes
      const transcriptsResult = await db.query<TranscriptContext>(
        `SELECT speaker, text, timestamp
         FROM transcripts
         WHERE conversation_id = $1
         AND timestamp > NOW() - INTERVAL '10 minutes'
         AND is_final = true
         ORDER BY timestamp ASC`,
        [conversationId]
      );

      if (transcriptsResult.rows.length === 0) {
        return;
      }

      // Get previous summaries
      const previousSummariesResult = await db.query(
        `SELECT summary
         FROM conversation_summaries
         WHERE conversation_id = $1
         ORDER BY created_at ASC`,
        [conversationId]
      );

      const previousSummaries = previousSummariesResult.rows.map(r => r.summary);

      // Generate new summary
      const summary = await openai.generateSummary(
        transcriptsResult.rows,
        previousSummaries
      );

      // Store summary
      await db.query(
        `INSERT INTO conversation_summaries (conversation_id, time_range, summary)
         VALUES ($1, $2, $3)`,
        [conversationId, timeRange, summary]
      );

      this.logger.info('Progressive summary generated', {
        conversationId,
        timeRange
      });

    } catch (error) {
      this.logger.error('Error generating progressive summary:', {
        conversationId,
        error
      });
    }
  }

  /**
   * Get conversation elapsed time
   */
  getElapsedTime(conversationId: string): number {
    const startTime = this.conversationStartTimes.get(conversationId);
    if (!startTime) return 0;
    return Date.now() - startTime;
  }

  /**
   * Check if conversation has passed warmup
   */
  hasPassedWarmup(conversationId: string): boolean {
    const elapsed = this.getElapsedTime(conversationId);
    return elapsed >= this.WARMUP_DURATION_MS;
  }

  /**
   * Get monitoring status
   */
  getStatus() {
    return {
      activeConversations: this.conversationStartTimes.size,
      conversations: Array.from(this.conversationStartTimes.entries()).map(([id, startTime]) => ({
        conversationId: id,
        elapsedMs: Date.now() - startTime,
        hasPassedWarmup: this.hasPassedWarmup(id),
        lastAnalysis: this.lastAnalysisTimes.get(id)
      }))
    };
  }
}

// Export singleton instance
export const aiAnalysis = new AIAnalysisService();
