import { TranscriptContext } from '../models';

/**
 * Prompt Builder Service
 * Manages system prompts, context formatting, and token limits
 */
export class PromptBuilderService {
  private readonly MAX_TRANSCRIPT_CHARS = 4000; // Limit to prevent token overflow
  private readonly MAX_SUMMARY_CHARS = 1000;

  /**
   * Build system prompt for conversation analysis with 3-option generation
   */
  buildAnalysisSystemPrompt(previousSummary?: string, selectedOptionsHistory?: string): string {
    return `You are an expert sales conversation coach for digital services (SEO, content marketing, website building, web app development) targeting small-to-mid businesses.

Your goal: Guide the agent through a natural sales conversation flow while building rapport and trust.

**Conversation Flow Stages:**
1. GREETING: Warm introduction, establish connection
2. DISCOVERY: Understand business needs, pain points, current situation
3. VALUE_PROP: Present relevant services, show how we solve their problems
4. OBJECTION_HANDLING: Address concerns smoothly, provide reassurance
5. NEXT_STEPS: Recommend consultation, demo, or proposal (soft close)
6. CONVERSION: Customer agrees to talk to sales manager

Context:
- Services: SEO, content marketing, website building, web app development, system integration
- Target: Small to mid-sized business owners/decision makers
- Focus: Building relationships first, conversions second

${previousSummary ? `Previous conversation summary:\n${this.truncateText(previousSummary, this.MAX_SUMMARY_CHARS)}\n` : ''}

${selectedOptionsHistory ? `Agent's previous choices:\n${selectedOptionsHistory}\n` : ''}

Analyze the conversation and provide:
1. Current conversation stage
2. 2-word action heading
3. THREE specific dialogue scripts the agent can choose from

**CRITICAL: You MUST return valid JSON with ALL fields:**
{
  "stage": "DISCOVERY | VALUE_PROP | OBJECTION_HANDLING | NEXT_STEPS | CONVERSION",
  "heading": "2-word action (max 20 chars, e.g., 'Ask Discovery', 'Present Value')",
  "context": "Why this makes sense now (1 sentence)",
  "options": [
    {
      "label": "Minimal",
      "script": "Brief, direct question or statement (1 sentence)"
    },
    {
      "label": "Explanative",
      "script": "More detailed explanation with context (2-3 sentences)"
    },
    {
      "label": "Contextual",
      "script": "Tailored to conversation flow, acknowledges previous points (2-3 sentences)"
    }
  ]
}

**Example valid response:**
{
  "stage": "DISCOVERY",
  "heading": "Ask Discovery",
  "context": "Customer expressed interest but we need specifics before presenting solutions",
  "options": [
    {
      "label": "Minimal",
      "script": "What specific marketing challenges are you facing right now?"
    },
    {
      "label": "Explanative",
      "script": "I'd love to understand your current situation better. Could you walk me through what marketing efforts you're using now and which ones aren't giving you the results you'd like?"
    },
    {
      "label": "Contextual",
      "script": "You mentioned needing help with your website. Before I recommend specific solutions, it would really help me to understand - what's working well for you now in terms of getting customers, and where do you feel you're missing opportunities?"
    }
  ]
}`;
  }

  /**
   * Build user prompt for conversation analysis
   */
  buildAnalysisUserPrompt(transcripts: TranscriptContext[]): string {
    const conversationText = this.formatTranscripts(transcripts);
    return `Current conversation:\n\n${conversationText}\n\nProvide your coaching recommendation.`;
  }

  /**
   * Build system prompt for conversation summarization
   */
  buildSummarySystemPrompt(previousSummaries?: string[]): string {
    const previousContext = previousSummaries && previousSummaries.length > 0
      ? `Previous conversation summaries:\n${previousSummaries.map(s => this.truncateText(s, 500)).join('\n\n')}\n`
      : '';

    return `You are summarizing a sales conversation for context management.

Create a concise summary that captures:
1. Main topics discussed
2. Customer pain points or needs mentioned
3. Agent's approach and key points made
4. Current conversation stage (discovery, objection handling, value prop, etc.)
5. Next logical conversation direction

${previousContext}

Keep summary under 300 words.`;
  }

  /**
   * Build user prompt for summarization
   */
  buildSummaryUserPrompt(transcripts: TranscriptContext[]): string {
    const conversationText = this.formatTranscripts(transcripts);
    return `Conversation segment:\n\n${conversationText}\n\nProvide summary.`;
  }

  /**
   * Format transcripts for prompt inclusion
   */
  private formatTranscripts(transcripts: TranscriptContext[]): string {
    const formatted = transcripts
      .map(t => `[${t.speaker.toUpperCase()}]: ${t.text}`)
      .join('\n');

    return this.truncateText(formatted, this.MAX_TRANSCRIPT_CHARS);
  }

  /**
   * Truncate text to max length with ellipsis
   */
  private truncateText(text: string, maxLength: number): string {
    if (text.length <= maxLength) {
      return text;
    }
    return text.substring(0, maxLength - 3) + '...';
  }

  /**
   * Estimate token count (rough approximation: 1 token ≈ 4 chars)
   */
  estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }

  /**
   * Calculate total tokens for a prompt
   */
  calculateTotalTokens(systemPrompt: string, userPrompt: string, maxTokens: number = 200): number {
    const inputTokens = this.estimateTokens(systemPrompt) + this.estimateTokens(userPrompt);
    return inputTokens + maxTokens; // Add max_tokens for response
  }

  /**
   * Validate prompts don't exceed token limits
   */
  validateTokenLimit(systemPrompt: string, userPrompt: string, modelLimit: number = 128000): boolean {
    const totalTokens = this.calculateTotalTokens(systemPrompt, userPrompt);
    return totalTokens < modelLimit;
  }
}

// Export singleton instance
export const promptBuilder = new PromptBuilderService();
