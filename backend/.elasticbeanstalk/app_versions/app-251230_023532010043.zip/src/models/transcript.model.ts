/**
 * Transcript Model
 * Represents individual speech-to-text segments
 */

export interface Transcript {
  id: string;
  conversation_id: string;
  speaker: Speaker;
  text: string;
  timestamp: Date;
  is_final: boolean;
  created_at: Date;
}

export type Speaker = 'caller' | 'agent';

export interface CreateTranscriptPayload {
  conversation_id: string;
  speaker: Speaker;
  text: string;
  is_final: boolean;
  timestamp?: Date;
}

export interface TranscriptBatch {
  conversation_id: string;
  transcripts: CreateTranscriptPayload[];
}
