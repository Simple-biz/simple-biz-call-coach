/**
 * Conversation Summary Model
 * Represents progressive summarization of conversations
 */

export interface ConversationSummary {
  id: string;
  conversation_id: string;
  time_range: string; // e.g., '0-10min', '10-20min'
  summary: string;
  created_at: Date;
}

export interface CreateSummaryPayload {
  conversation_id: string;
  time_range: string;
  summary: string;
}

export interface SummaryContext {
  previous_summaries: ConversationSummary[];
  recent_transcripts: string;
  time_elapsed_minutes: number;
}
