/**
 * Conversation Model
 * Represents a call coaching session
 */

export interface Conversation {
  id: string;
  agent_id: string;
  start_time: Date;
  end_time: Date | null;
  status: ConversationStatus;
  metadata: Record<string, any> | null;
  created_at: Date;
  updated_at: Date;
}

export type ConversationStatus = 'active' | 'ended' | 'error';

export interface CreateConversationPayload {
  agent_id: string;
  metadata?: Record<string, any>;
}

export interface UpdateConversationPayload {
  end_time?: Date;
  status?: ConversationStatus;
  metadata?: Record<string, any>;
}
