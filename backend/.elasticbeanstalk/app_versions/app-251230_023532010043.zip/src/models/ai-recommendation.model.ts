/**
 * AI Recommendation Model
 * Represents AI-generated coaching with 3 selectable dialogue options
 */

export type ConversationStage =
  | 'GREETING'
  | 'DISCOVERY'
  | 'VALUE_PROP'
  | 'OBJECTION_HANDLING'
  | 'NEXT_STEPS'
  | 'CONVERSION';

export interface DialogueOption {
  label: string; // "Minimal", "Explanative", "Contextual"
  script: string; // Exact words to say
}

export interface AIRecommendation {
  id: string;
  conversation_id: string;
  heading: string; // Max 2 words (e.g., "Ask Discovery")
  stage: ConversationStage;
  context: string | null; // Why this recommendation

  // 3 dialogue options
  option1_label: string;
  option1_script: string;
  option2_label: string;
  option2_script: string;
  option3_label: string;
  option3_script: string;

  // User selection tracking
  selected_option: 1 | 2 | 3 | null;
  selected_at: Date | null;
  created_at: Date;
}

export interface CreateAIRecommendationPayload {
  conversation_id: string;
  heading: string;
  stage: ConversationStage;
  context?: string;

  option1_label: string;
  option1_script: string;
  option2_label: string;
  option2_script: string;
  option3_label: string;
  option3_script: string;
}

export interface OptionSelectionPayload {
  recommendation_id: string;
  selected_option: 1 | 2 | 3;
}

export interface AIAnalysisRequest {
  conversation_id: string;
  transcripts: TranscriptContext[];
  summary?: string;
}

export interface TranscriptContext {
  speaker: 'caller' | 'agent';
  text: string;
  timestamp: Date;
}
